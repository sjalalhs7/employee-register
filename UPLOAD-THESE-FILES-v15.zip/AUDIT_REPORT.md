# MSM Long Roll – Full Website Audit (2 Oct 2026)

Scope: every file in `employee-register-main.zip` (68 files). Method: static scan of all references, IDs, rules and PWA files; JS syntax check (12 scripts); headless-browser run over HTTP; computed-style scan of every element for blue/violet (light + dark); visual check of login, dashboard and import preview.

## FIXED in this delivery
| # | Problem | Evidence | Fix |
|---|---------|----------|-----|
| 1 | Import blocked all 450 rows | The Excel has only a Client/Project column (clients like "113. Saudi Pak Tower"), but the code looked for a SECTOR name there. My first fix (name cleaning) was based on a wrong assumption and was not enough. | Import preview now has an **"Import into Sector"** picker. Sector is taken from the picker, else the file name ("Islamabad Sector"), else the Region's only Sector. Tested: 5/5 rows Ready in both cases |
| 2 | 341 blue/violet colour values in code | colour scan of index.html | Recoloured at source to emerald / orange / cream |
| 3 | Browser bar + PWA colours still navy | `theme-color #0c1a2a`, manifest `#071522` | Changed to emerald `#047857` / cream |
| 4 | hero image 31 % dark blue | pixel scan | Recoloured (`hero-reference.png`) |
| 5 | Logo files 1.1 MB each (identical duplicates) | file sizes | Resized to 640 px, 289 KB, same filenames |
| 6 | Import table showed empty boxes instead of ✅/❌ on the office PC | your screenshot | Replaced with text badges "✓ Ready / ✗ Blocked"; emoji/symbol font fallback added |
| 7 | CNIC formats inconsistent (row 142 had no dashes) | screenshot | Import now writes 12345-1234567-1 |
| 8 | 7 images without alt text | scan | `alt` added |
| 9 | Old cached files kept showing | `sw.js` cache name unchanged | New cache name `…orange-emerald-v3` |

## VERIFIED OK
No missing local files or 404s, no case-mismatch (GitHub is case-sensitive), JS syntax 0 errors, 0 page errors, 0 blue elements, `lang`/viewport/title present, no `eval`/`document.write`, Storage rules require login + 5 MB + image/PDF only.

## NOT FIXED – needs your decision (risks)
1. **Two Firestore rule files** (`Firestore.rules` 8 KB and `firestore.rules` 4.7 KB) differ. `firebase.json` uses the lower-case one. I could not see what is live in the Firebase console – open Firestore → Rules and compare. Delete the unused copy afterwards.
2. **Regional and Client users can delete records** (rules allow `delete` inside their scope). Intentional? If not, restrict delete to Parent.
3. **Email case**: Firestore rules look up `authorizedUsers/{email}` without `.lower()` (Storage rules do lower it). The user document IDs must be all lower-case.
4. **Firebase API key is public in the page.** Normal for Firebase, but restrict the key to your domain in Google Cloud Console.
5. **Dead/duplicate code**: `msmRenderSectorManager` is defined 4 times (last one wins); element IDs `msmNewRegionName/SectorName/SectorRegion` are duplicated in two templates. Works today, but a future edit can break Sector Manager.
6. **Clutter**: ~15 README/AUDIT files, two old full copies of the site (`MSM_SECURITY_GUARDS_PVT_LTD_STABLE_FINAL.html` 2.3 MB, `MSM_Longroll_Dashboard.html`), Android project files, `msm-shield-reference.png.png`, `msm-shield-reference` (no extension). Not used by the site; risk of editing the wrong file.
7. 59 `innerHTML` writes: not individually reviewed; user text is escaped in the places I checked (`escapeHtml`).

## NOT VERIFIED (could not test)
Real Firebase login, real data screens (tables/forms/Sector Manager), live Firestore rules, phone/APK behaviour, printing/export.

## Update 3 (Oct 2026) – Import/Export, Home forms, Navigation, CNIC uploads
- **Why upload stopped after the update (fact):** the new Region/Sector security check blocked every row because the Excel has no Sector column. Fixed with Region + Sector pickers in the import preview.
- **Add Region / Add Sector:** old code used `prompt()` pop-ups, which phones and installed apps often block. Replaced with proper forms (tested with simulated Firestore).
- **Navigation:** real dropdown menus (Regions, Database, Company), touch-friendly, closes on outside tap / Esc.
- **Police Verification Upload and Guard Photo Upload:** file names containing the guard's CNIC are matched automatically; preview first, then upload to Storage and attach to the record (5 MB limit).
- **Not done:** Export Region/Sector scope selector; a full separate Data-Form page (Data Form menu item opens the existing form); latent bug: `msmHomeAddSectorLocation` treats sectors as objects but the catalog holds strings.
- **Not tested:** real Firestore/Storage writes, real 450-row Excel, phones.

## Update 4
- Header title doubled: h1 text-shadow showed through transparent gradient text. Fixed (flat gold gradient, no 3D/blink).
- Side navigation added (drawer on phone, fixed on PC ≥1100px) with quick CNIC/name search; top dropdown nav kept.
- Glass + clay mix strengthened on cards/buttons in light and dark.
- Uploaded V76 zip and App_Ideas catalog are separate projects: not merged.
- Still not done: Export Region/Sector selector, separate Data-Form page, extra features beyond quick search. Not tested with real Firebase/Excel/phone.

## Update 5 (hang fixes, light-mode text, finder, homepage sections)
- **Hang / blockage (measured):** home page had 64 endless animations and 54 blur-effect elements; now 1 and 6. Falling petals/leaves/rain removed. Long tasks: none in test.
- **Light-mode text:** white-on-light text on the login info card fixed; header bands made deeper emerald. Automated contrast scan: login 0 issues. Stat-star numbers sit on gradient shapes the scanner cannot read; checked by eye only.
- **Logo:** sticky top bar with logo on every app screen; logo also in the side menu.
- **Find data by CNIC / Name / MSM No.:** top bar button, side menu and homepage cards. Searches loaded records, and for a full 13-digit CNIC also queries the database.
- **Homepage:** new service cards - Find by CNIC, Find by Name, Police Verification, Guard Photos, Data Form, Import/Export.
- **Shared files:** V76 zip design blueprint (logo stage, service strip, side + top nav, performance rules) applied. App_Ideas catalog is a generic idea list; nothing in it fits this database, so nothing copied from it.
- **Not done:** Export Region/Sector selector; separate full-page Data Form; two-column PC login layout; bottom nav on phone. Not tested on real Firebase, Excel or a phone.

## Update 6 - reference files
- V76 zip (AI-Syed Jalal) login + approved UI concept image: split login (brand panel left with logo stage, headline, 4 numbered feature cards; login card right), homepage hero with logo stage and quick buttons, service tiles, sidebar + top bar, mobile bottom navigation. All applied to MSM in orange / emerald-gold glass + clay, light-mode readable.
- App_Ideas_Collection_Catalog.html is an unstyled list of developer project ideas (markdown previewer, quiz, weather, kanban). Nothing in it applies to a guard database. Not copied; ideas worth considering later: kanban board for pending verifications.
- Build label now v8 (bottom centre).
- Not done: animated 3D logo, floating icon effects (removed on purpose, they caused the hang); real-phone and real-Firebase testing.

## Update 7 (build v9) - completeness, filters, fast import, print-size images
- Long Roll import: 3000 rows tested = 6 batches of 500, 3 committed in parallel (simulated 300 ms latency: 0.6 s vs 1.8 s serial). Real speed depends on internet and Firestore rules. Preview now draws the first 300 rows only (3000 rows used to freeze the page); totals stay exact.
- Conditional formatting: guards missing any of 10 key fields (name, CNIC, MSM no., father, mobile, DOB, address, client, photo, police verification) are highlighted yellow (1-3 missing) or orange (4+), with a "Missing N" badge listing the fields on hover.
- Filters: Data completeness (all / incomplete / complete / missing basic data / missing photo / missing police verification) plus existing Client, Sector, Location, Supervisor, Station, Rank, Status, dates. Search by name/CNIC/MSM no. in table, side menu and Find window.
- Image fit: photos become 600x800 (3:4) JPEG ~50 KB; verification images max 1754 px (A4 page) JPEG under ~450 KB. Stored where the form and print preview read them (photoData, policeVerifDoc). Print CSS keeps photo and verification pages unsplit.
- Limits: PDFs are not accepted in the verification upload (images only). A 1 MB Firestore document limit applies, so two large images per guard are compressed. Print preview tested by CSS only, not on a real printer.
- Not done: data-analysis dashboard (only the "N of M incomplete" counter), export Region/Sector selector, separate Data-Form page. Zero bugs cannot be guaranteed; tested on simulated data in desktop-size and phone-size Chromium only.

## Update 8 - FULL AUDIT of build v10 (3 Oct 2026)
Method: static scan (IDs, inline handlers, called functions), JS syntax (14 scripts), click-crawl of 40 navigation items (sidebar, dropdowns, cards, hero, top bar), view-switch check, light-mode contrast scan, performance profile, 3000-row import simulation, completeness filter, image-fit test. Desktop (1366 px) and phone (390 px) Chromium, simulated data.

| # | Finding | Severity | Status |
|---|---------|----------|--------|
| 1 | Script errors / failed clicks in 40 navigation items | - | 0 found |
| 2 | Inline handlers calling undefined functions | - | 0 found |
| 3 | Navigation: Database, Form, Audit, Admin, Transfer, About screens all open | - | OK |
| 4 | Pale-mint subtitle ("Regional Distribution of Guards...") unreadable in light mode, same colour on region contact labels | Medium | FIXED |
| 5 | Superseded duplicate code (old Upload Center, old Sector bar, 2.7 KB) could be picked up by a future edit | Low | REMOVED |
| 6 | Endless animations: login 0, home 1 (was 64); blur elements 4-6 (was 54) | High (hang) | FIXED earlier, re-verified |
| 7 | Police verification stored as inline image in the record (the form itself uploads to Storage). Fine for one A4 image (<450 KB) but Firestore documents are limited to 1 MB | Medium | OPEN - keep verification under ~450 KB (auto-compressed) |
| 8 | Duplicate IDs msmNewRegionName / msmNewSectorName / msmNewSectorRegion in two templates of Sector Manager (pre-existing) | Medium | OPEN - works while only one renders; fix needs rewrite of Sector Manager |
| 9 | Two Firestore rules files differ (Firestore.rules vs firestore.rules); regional/client users may delete records; rules use email without lower-case | High (security) | OPEN - needs your decision and Firebase console access |
| 10 | Stat-star numbers flagged by contrast scanner (white on emerald/orange shape drawn by a sibling element) | Info | False positive, verified by eye |
| 11 | PDF verification cannot be uploaded through the Upload Center (images only); the Data Form still accepts PDF | Low | OPEN |
| 12 | Print preview checked by CSS rules only | Medium | OPEN - needs one real print test |

Untested: real Firebase login/data, real Excel (3000 rows), real printer, real phone, other browsers (Safari/Firefox).
Honest status: no script errors found in the tested paths; zero bugs cannot be proven.

## FINAL (build v11, 3 Oct 2026)
Closed in v11:
- Guards saved through the form keep their photo/verification as Storage links (photoUrl / policeVerificationUrl). My completeness check ignored photoUrl and would have shown them as "Missing photo" - FIXED. Print now also accepts a photo link.
- Upload Center now saves to Firebase Storage exactly like the form (no 1 MB record risk); falls back to a small inline image only if Storage fails. PDF verification is now accepted (max 5 MB).
- Duplicate element IDs: none present in the page at runtime (checked after opening every screen), so the old duplicates in dead Sector Manager code do not affect anything.
Regression (PC 1366 px and phone 390 px, simulated data): 41 menu items clicked, 0 errors; completeness filter OK; 3000-row import = 6 batches of 500, 3 in parallel; 0 duplicate IDs; build label present.

STILL OPEN (needs you):
1. Firestore rules: two files differ (Firestore.rules 304 lines, region-aware; firestore.rules 110 lines, used by firebase.json). Open Firebase console > Firestore > Rules and compare with what is live; keep only one file in the repo. Regional/Client users can delete records inside their scope; email in rules is not lower-cased. NOT changed by me because wrong rules can lock every user out.
2. Print preview: the app's own code fills name, photo and verification page correctly (checked), and the CSS fixes the verification page to 8.5x11 in with the image contained. I could NOT render the real print layout in my test browser, so print one guard with photo + verification on your PC and check the pages.
3. Not tested anywhere: real Firebase login/data, your real Excel, a real phone, Safari/Firefox, real printer.

## Update 10 - Import fix (build v12)
Reported: 250 guards, "no data uploaded" (running build v10).
Most likely cause (inference, not seen live): for Regional Office users the database rules accept a guard record only if its Sector is listed inside the Region document on the server, but the app never checked or maintained that list, and one rejected row makes the whole 500-row batch fail with nothing saved.
v12 changes:
- Pre-flight check before saving: reads the Region document; if a Sector is missing it adds it automatically (allowed for the user's own Region); if that is not possible it stops with a plain explanation of what the Parent admin must do.
- Failed batch no longer loses everything: good rows are saved, bad rows are listed (row, name, CNIC, error code).
- Systemic errors (rules, offline, signed out) show a persistent report window with Copy report instead of a short toast.
- Preview says exactly why nothing can be imported and what to choose.
Tested with simulated database: auto-heal (250 rows saved), heal denied, all rows denied, 1 bad row among 250 (249 saved, 1 reported), Region missing, 2500 rows.
Not tested: your real database and rules. If it still fails, send a photo of the red/white report window.

## Update 11 - Upload Health Check (build v13)
Problem: "data upload fails every time" could not be diagnosed without access to the live Firebase project.
New: "Upload Health Check" (side menu, Database dropdown, homepage card, and button inside the import error window). With the user's own login it tests, in about 10 seconds: internet, website version, user record and role, Region and Sectors on the server, whether the Excel reader library can load (network may block cdnjs/sheetjs), a REAL batch write of 3 test guards (then deleted), and a real photo upload to Storage. It prints PASS/WARN/FAIL with the exact Firebase error code and what it means.
Also: third download source for the Excel library (jsdelivr).
Tested with simulated database: all-fine, rules deny writes, Region missing, Excel library blocked + Storage denied.
Needed from the owner: run it once on the real site, send a photo of the result, plus the Excel file (first 20 rows, names changed) so the real file parser can be tested.

## Update 12 - build v14 (everything requested that can be built is built)
New in v14:
- Export Long Roll asks for Region, Sector and Data (all / incomplete / complete) before saving the Excel. Tested: 200 guards -> 100 (North Region) -> 30 (North + Islamabad Sector + incomplete).
- Import preview lists Excel columns that were NOT recognised and required fields not found in the file, so no data is lost silently.
- Homepage "Data Health" card: % complete, incomplete guards, missing basic data, missing photo, missing police verification; each box opens those guards in the Database, highlighted.
- Data Form is its own screen (verified: opens the enrolment form only, 48 fields, no table).
Regression (PC 1366 px + phone 390 px, simulated data): 44 menu items clicked, 0 errors; 3000-row import in parallel batches; 6 import failure scenarios; Upload Health Check 4 scenarios; uploads/completeness; export scope; 0 duplicate IDs.

REMAINING - cannot be closed from here:
1. Run "Upload Health Check" on the real site (needs your real login).
2. Real Excel file (not provided; the real header names are unknown, the new column report will show any unrecognised column).
3. One real print: the app asks to adjust the photo before printing; layout could not be rendered in the test browser.
4. Firestore rules: two files differ; decision needed on delete rights for Regional/Client users. Not changed because wrong rules lock every user out.
5. Real phone, Safari, Firefox.

## Update 13 - build v15: "import complete, but 0 guards shown"
Evidence: owner photo, build v12: toast "Import complete: 249 guards saved", Database screen shows 0 entries / TOTAL 0.
Reading: the guards list for a Regional login is loaded by queries built at login from the user's regionId and from the Sector list known at that moment. The import tagged records with the region id taken from the app's catalog, which can differ from the user's own regionId, and the Sector list can still be empty at login. Saved guards then fall outside every query. (Inference - live rules and data not seen.)
Fixes:
- Imported guards are tagged with the user's own regionId/region (what the list query and the rules use).
- Regional list now reads by Region id AND by every Sector of the Region (Sector list read from the server), also the legacy Client/Project tag; handles deletions; re-subscribes when the catalogs finish loading and after every import.
- After an import the app shows the new rows at once, re-reads from the server, and after 5 s warns in plain words if the server does not return them ("Saved, but not visible to your login").
- Upload Health Check now also tests "Reading guards" with the same queries the app uses.
Tested with an in-memory database: mismatching catalog region id (249/249 visible), regionId query refused (249/249 via sector queries), all reads refused (warning shown, nothing hidden).
IMPORTANT: do not re-import the same Excel before the first 249 are visible again; an invisible guard cannot be recognised as existing and would be saved twice.
